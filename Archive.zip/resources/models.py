# resources/models.py
from django.db import models


class Tag(models.Model):
    name = models.CharField(max_length=100, unique=True)
    def __str__(self):
        return self.name


class ResourceLink(models.Model):
    LINK_TYPE_CHOICES = [
        ('EXTERNAL', 'External URL'),
        ('UPLOAD', 'File Upload'),
    ]

    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    tags = models.ManyToManyField(Tag, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    link_type = models.CharField(max_length=10, choices=LINK_TYPE_CHOICES, default='EXTERNAL')
    url = models.URLField(max_length=500, blank=True, help_text="Use this for an External URL.")
    file = models.FileField(upload_to='resources/', blank=True, help_text="Use this for a File Upload.")

    def get_url(self):
        """Returns the correct URL based on the link type."""
        if self.link_type == 'UPLOAD' and self.file:
            return self.file.url
        return self.url

    def __str__(self):
        return self.title

    class Meta:
        ordering = ['-created_at']