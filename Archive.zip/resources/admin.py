# resources/admin.py
from django.contrib import admin
from .models import ResourceLink, Tag

class ResourceLinkAdmin(admin.ModelAdmin):
    # This makes the tag selection interface much more user-friendly
    filter_horizontal = ('tags',)

admin.site.register(ResourceLink, ResourceLinkAdmin)
admin.site.register(Tag)