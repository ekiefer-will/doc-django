# resources/serializers.py
from rest_framework import serializers
from .models import ResourceLink

class ResourceLinkSerializer(serializers.ModelSerializer):
    tags = serializers.StringRelatedField(many=True, read_only=True)
    url = serializers.SerializerMethodField()

    class Meta:
        model = ResourceLink
        fields = ['id', 'title', 'description', 'url', 'tags', 'created_at']

    def get_url(self, obj):
        return obj.get_url()