# resources/views.py
import qrcode
import io
import re
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework import viewsets, permissions
from .models import ResourceLink
from .serializers import ResourceLinkSerializer

class ResourceLinkViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = ResourceLink.objects.all()
    serializer_class = ResourceLinkSerializer
    permission_classes = [permissions.AllowAny]

def generate_qr_code(request, pk):
    resource_link = get_object_or_404(ResourceLink, pk=pk)
    target_url = resource_link.get_url()
    
    qr = qrcode.QRCode(version=1, box_size=10, border=4)
    qr.add_data(target_url)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    buffer = io.BytesIO()
    img.save(buffer, "PNG")
    buffer.seek(0)
    
    response = HttpResponse(buffer, content_type="image/png")
    sanitized_title = re.sub(r'[^a-z0-9_]', '', resource_link.title.lower().replace(' ', '_'))
    filename = f"{sanitized_title}_qr.png"
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response