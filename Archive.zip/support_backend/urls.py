# support_backend/urls.py
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from resources import views as resource_views

router = routers.DefaultRouter()
router.register(r'links', resource_views.ResourceLinkViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
    
    # Add this new path for QR codes
    path('api/links/<int:pk>/qrcode/', resource_views.generate_qr_code, name='link-qrcode'),
]